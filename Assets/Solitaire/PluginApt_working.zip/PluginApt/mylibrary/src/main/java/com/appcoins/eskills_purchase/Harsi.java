package com.appcoins.eskills_purchase;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import java.util.List;
import com.unity3d.player.UnityPlayer;
public class Harsi extends Activity{


    Context mainContext;
    String urlToCheck;

    public  String LaunchGameStart(){
        return  "Sudhakar is great";

    }
    public void Init(Activity context)
    {

        Intent loginIntent = new Intent(context, PurchaseActivity.class);
        context.startActivity(loginIntent);

    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Harsi", "Sudhakar CalledCalledCalled >>>>>>>>>>>");

        Intent intent = new Intent( Intent.ACTION_VIEW);
        Bundle bundle = getIntent().getExtras();
        Log.d("URLLlqqq>>", "urlToCheck");

        if(bundle.getString("urlToCheck")!= null)
        {
            Log.d("URLLlqqq>>", bundle.getString("urlToCheck"));

            Uri uri =  Uri.parse(bundle.getString("urlToCheck"));
            intent.setPackage("com.appcoins.wallet");
            intent.setData(uri);
        }

        startActivityForResult(intent, REQUEST_CODE);
    }

    public void startNewActivity(Context context, String packageName) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent != null) {
            // We found the activity now start the activity
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } else {
            // Bring user to the market or let them choose an app?
            intent = new Intent(Intent.ACTION_VIEW);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setData(Uri.parse("market://details?id=" + packageName));
            context.startActivity(intent);
        }
    }
    public void startMyNewActivity(Context context, String packageName) {
//        Intent intent = buildTargetIntent(context);
        /*
        if (intent != null) {
            // We found the activity now start the activity
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } else {
            // Bring user to the market or let them choose an app?
            intent = new Intent(Intent.ACTION_VIEW);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setData(Uri.parse("market://details?id=" + packageName));
            context.startActivity(intent);
        }

         */
//        ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
//                new ActivityResultCallback<Uri>() {
//                    @Override
//                    public void onActivityResult(Uri uri) {
//                        // Handle the returned Uri
//                    }
//                });


//        Intent intent = new Intent(context, PurchaseActivity.class);
//        intent.setAction(Intent.ACTION_VIEW);
//        Uri uri =  Uri.parse( "https://apichain.catappult.io/transaction/eskills?value=1&currency=USD&product=summer_battle&user_name=user1&user_id=a25cd286&domain=com.appcoins.eskills2048&environment=SANDBOX&number_of_users=2" );
//        intent.setPackage("com.appcoins.wallet");
//        intent.setData(uri);

//        context.startActivity(intent);
        Log.d("Called", "Sudhakar CalledCalledCalled >>>>>>>>>>>");

        UnityPlayer.UnitySendMessage("AptiodeManager", "ReceiveData","<><><>sudhakar");
        this.urlToCheck = packageName;
        Intent intent = new Intent(((Activity) context),Harsi.class);
        intent.putExtra("urlToCheck",packageName);

        ((Activity) context).startActivity(intent);


//        Intent intent = new Intent( Intent.ACTION_VIEW);
//        Uri uri =  Uri.parse( "https://apichain.catappult.io/transaction/eskills?value=1&currency=USD&product=summer_battle&user_name=user1&user_id=a25cd286&domain=com.appcoins.eskills2048&environment=SANDBOX&number_of_users=2" );
//        intent.setPackage("com.appcoins.wallet");
//        intent.setData(uri);
//
//        ((Activity) context).startActivityForResult(intent, REQUEST_CODE);

    }
    private static final int REQUEST_CODE = 123;

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Called", "onActivityResult CalledCalledCalled >>>>>>>>>>>");

        if ( requestCode == REQUEST_CODE ) {
            Log.d("Harsi", "Sudhakar Harsi >>>>>>>>>>>");
            Log.d("TAG", "${data?.getStringExtra(SESSION_KEY)}");
            Bundle bundle = data.getExtras();
            if (bundle != null) {
                for (String key : bundle.keySet()) {
                    String hmaesv =key + ","+ (bundle.get(key) != null ? bundle.get(key) : "NULL").toString();
                    UnityPlayer.UnitySendMessage("AptiodeManager", "ReceiveData","Harsith ......>>>");

                    UnityPlayer.UnitySendMessage("AptiodeManager", "ReceiveData",hmaesv);
                    Log.e("Harsi", key + " : " + (bundle.get(key) != null ? bundle.get(key) : "NULL"));
                }

                UnityPlayer.UnitySendMessage("AptiodeManager", "StartGame","Start");

            }

            finish();
        }
        else{
            Log.d("Sudhakar>>>>", "Sudhakar Harsi >>>>>>>>>>>");

        }
    }

    private Intent buildTargetIntent(Context context) {
        Intent intent = new Intent( Intent.ACTION_VIEW);
        Uri uri =  Uri.parse( "https://apichain.catappult.io/transaction/eskills?value=1&currency=USD&product=summer_battle&user_name=user1&user_id=a25cd286&domain=com.appcoins.eskills2048&environment=SANDBOX&number_of_users=2" );

        intent.setData(uri);
        // Check if there is an application that can process the AppCoins Billing flow
        List<ApplicationInfo> packages;
        PackageManager pm;

        pm = context.getPackageManager();
        packages = pm.getInstalledApplications(0);
        for (ApplicationInfo packageInfo : packages) {
            if(packageInfo.packageName.equals("cm.aptoide.pt"))
            {
                intent.setPackage(packageInfo.packageName);
            }
            else if(packageInfo.packageName.equals("com.appcoins.wallet")){
                intent.setPackage(packageInfo.packageName);

            }
        }

        return intent;
    }
}
