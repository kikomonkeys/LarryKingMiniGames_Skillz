package com.appcoins.eskills_purchase;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.List;

public class PurchaseActivity extends Activity {

    private static final int REQUEST_CODE = 123;
    private static final int RESULT_OK = 1;

    public static final String USER_ID = "USER_ID";
    public static final String PACKAGE_NAME = "PACKAGE_NAME";
    public static final String ROOM_ID = "ROOM_ID";
    public static final String WALLET_ADDRESS = "WALLET_ADDRESS";
    public static final String SESSION = "SESSION";

    private final String userId = "string_user_id";

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = new Intent( Intent.ACTION_VIEW);
        Uri uri =  Uri.parse( "https://apichain.catappult.io/transaction/eskills?value=1&currency=USD&product=summer_battle&user_name=user1&user_id=a25cd286&domain=com.appcoins.eskills2048&environment=SANDBOX&number_of_users=2" );
        intent.setPackage("com.appcoins.wallet");
        intent.setData(uri);

        startActivityForResult(intent, REQUEST_CODE);

//        Uri uri =  Uri.parse("https://apichain.catappult.io/transaction/eskills?value=1&currency=USD&product=Solitaire_battle&user_name=SM&user_id=Sudhakar&domain=com.piper.testapp&environment=SANDBOX&number_of_users=2");
//
////        Uri uri =  Uri.parse( "https://apichain.catappult.io/transaction/eskills?value=1&currency=USD&product=summer_battle&user_name=user1&user_id=a25cd286&domain=com.appcoins.eskills2048&environment=SANDBOX&number_of_users=2" );
////        Intent intent =
////                buildTargetIntent(uri);
////        startActivityForResult(intent, REQUEST_CODE);

    }
    public static String LaunchGameStart(){
        return  "Sudhakar is great";

    }


    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Called", "onActivityResult CalledCalledCalled >>>>>>>>>>>");

        if ( requestCode == REQUEST_CODE ) {
            Log.d("Harsi", "Sudhakar Harsi >>>>>>>>>>>");
            Log.d("TAG", "${data?.getStringExtra(SESSION_KEY)}");
            Bundle bundle = data.getExtras();
            if (bundle != null) {
                for (String key : bundle.keySet()) {
                    Log.e("Harsi", key + " : " + (bundle.get(key) != null ? bundle.get(key) : "NULL"));
                }
            }
            finish();
        }
        else{
            Log.d("Sudhakar>>>>", "Sudhakar Harsi >>>>>>>>>>>");

        }
    }

}
