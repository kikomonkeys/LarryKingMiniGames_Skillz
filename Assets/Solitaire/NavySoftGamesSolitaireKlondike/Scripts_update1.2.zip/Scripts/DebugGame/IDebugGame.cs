﻿using UnityEngine;
using System.Collections.Generic;

public interface IDebugGame {
	List<IDebugCardInfo> GetAllCards();
}
