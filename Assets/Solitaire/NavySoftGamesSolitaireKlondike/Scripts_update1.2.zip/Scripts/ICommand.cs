﻿using UnityEngine;
using System.Collections;

public interface ICommand{
	void execute ();
	void unexecute ();
}
