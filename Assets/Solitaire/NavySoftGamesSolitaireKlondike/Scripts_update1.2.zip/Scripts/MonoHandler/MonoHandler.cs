﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonoHandler : MonoBehaviour {

	public virtual void GUIEditor(){
	}
}
